script_efficient_mesa_data_storage.py
Pagina
/1

#!/usr/bin/env python
# coding: utf-8

import numpy as np
import matplotlib.pyplot as plt
import mesaPlot as mp
import cmasher as cm
from scipy.interpolate import interp1d
import tulips
from matplotlib.colors import SymLogNorm, LogNorm, Normalize
from tqdm.notebook import tqdm

DATA_DIR = "../../compactness_models/models_info_to_6_Msun/"
PLOT_DIR = "Plots/"
MASSES_ARY = [19.0, 20.0, 21.0, 22.0, 24.0, 25.0]
DIR_NAMES = ["m" + str(m) + "/LOGS/LOGS" for m in MASSES_ARY]
p = mp.plot(rcparams_fixed=False)

def find_closest(ary, value):
    return np.abs(ary - value).argmin()

def create_total_profiles_data_from_profs(m, var_names, y_ary=np.linspace(0, 20, 100), num_times=-1, yaxis="mass"):
    """ Create a structured array containing the data of all profiles 
    
    Parameters
    ----------
    m: mesaPlot object
        object containing the mesa data
    var_names: list of str
        List of property names
    y_ary: np.ndarray
        Array of y values (for example the mass)
    num_times: int
        Number of times to consider (should not exceed the total number of profiles)
    yaxis: mass by default, but can be changed to other axis as well
    Returns
    -------
    total_profile_data: structure np.ndarray
        Array containing fields for each property. A matrix of the property is saved in the form (mass_ind, time_ind)
        
    Example
    -------
    Access the C12 mass fraction profile at time index -1 with profile_data["c12"][0][:, -1] 
    Access the evolution of C12 mass fraction at mass coordinate -1 with profile_data["c12"][0][-1]
    """
    # Make sure we can read profiles
    m.loadProfile(num=-1)
    # Load a number of profiles, by default all
    max_num_prof = int(m.prof_ind["profile"][-1])
    if num_times <= 0:
        num_times = max_num_prof
    assert num_times <= max_num_prof
    
    # Create a structured array containing the values of the property as a matrix (mass_ind, time_ind)
    # This efficient data storage allows plotting Kippenhahn diagrams very quickly
    dtype = [(var, "f8", (len(y_ary), num_times)) for var in var_names]
    print(dtype)
    total_profile_data = np.zeros((1), dtype=dtype) 
    # Read each stored profile
    ip = m.iterateProfiles(rng=[-1, -1], silent=True)
    zones = []
   
    for ind, i in tqdm(enumerate(ip)):
        for var in var_names:
            z = m.prof.data[var]
            y = m.prof.data[yaxis]
            f = interp1d(y, z, bounds_error=False, fill_value=np.nan)
            var_z = f(y_ary)
            total_profile_data[var][0][:, ind] = var_z
    return total_profile_data


# Testing that this works:

mass_ind = 0
m = m_list[mass_ind] # mesaplot object
prof_test = create_total_profiles_data_from_profs(m, var_names=["c12", "logRho", "eps_nuc", "non_nuc_neu"], y_ary=np.linspace(0, 20, 1000), num_times=-1, yaxis="mass")
prop_name = "logRho"
print(prof_test[prop_name][0])
print(prof_test[prop_name][0][:, -1])
print(prof_test[prop_name][0][-1])

# Example: classical Kippenhahn diagram with nuc. burning as color
fig = plt.figure()
fig.patch.set_alpha(1)
ax = plt.gca()

# find log age corresponding to mdoel numbers of saved profiles
models = m.prof_ind["model"]
log_time_to_cc = np.log10(m.hist.star_age[-1]+3.0e-9-m.hist.star_age)
ind_mods = [find_closest(m.hist.model_number, mod) for mod in models]
final_times = log_time_to_cc[ind_mods]

y_ary = np.linspace(0, 20, 1000)
prop_name = "non_nuc_neu"
prop_lim = (-15, 12)
log = False
num_levels = 30
cmap = tulips.ROBS_CMAP_ENERGY
xlim = (7, -8)

eps_nuc_y = prof_test["eps_nuc"][0]
eps_nuc_y[eps_nuc_y < 0] = 0
eps_neu_y = prof_test["non_nuc_neu"][0]
eps_neu_y[eps_neu_y < 0] = 0
diff_ary = eps_nuc_y - eps_neu_y
burn = np.sign(diff_ary) * np.log10(np.max([np.abs(diff_ary), np.ones_like(diff_ary)], axis=0))

X, Y = np.meshgrid(final_times, y_ary)
Z = burn
if log:
    Z = np.log10(Z)

CS2 = ax.contourf(X, Y, Z, cmap=cmap, levels=np.round(np.linspace(prop_lim[0], prop_lim[1], num_levels), 3),
                  vmin=prop_lim[0], vmax=prop_lim[1])
        
ax.invert_xaxis()    
ax.set_ylabel("$m \,[\\rm{M}_{\\odot}]$")
ax.set_xlabel(r'$\log_{10}$(time until collapse / yr)')
ax.set_title(str(MASSES_ARY[mass_ind]) + "$\,\\rm{M}_{\\odot}$")

# Colorbar
bar = fig.colorbar(CS2, ax=ax, 
                   # orientation="horizontal", location="top", anchor=(0, 0), 
                   pad=0.05)
ax.set_xlim(xlim[0], xlim[1])


# Test Kippenahn with log radius on Y axis

mass_ind = 2
m = m_list[mass_ind]
y_ary = 10**np.linspace(-2, 3.1, 2000)
prof_test_radius = create_total_profiles_data_from_profs(m, var_names=["c12", "logRho", "eps_nuc", "non_nuc_neu"], y_ary=y_ary, num_times=-1, yaxis="radius")

fig = plt.figure()
fig.patch.set_alpha(1)
ax = plt.gca()

# find log age corresponding to mdoel numbers of saved profiles
models = m.prof_ind["model"]
log_time_to_cc = np.log10(m.hist.star_age[-1]+3.0e-9-m.hist.star_age)
ind_mods = [find_closest(m.hist.model_number, mod) for mod in models]
final_times = log_time_to_cc[ind_mods]

prop_name = "non_nuc_neu"
prop_lim = (-15, 12)
log = False
num_levels = 30
cmap = tulips.ROBS_CMAP_ENERGY
xlim = (7, -8)

eps_nuc_y = prof_test_radius["eps_nuc"][0]
eps_nuc_y[eps_nuc_y < 0] = 0
eps_neu_y = prof_test_radius["non_nuc_neu"][0]
eps_neu_y[eps_neu_y < 0] = 0
diff_ary = eps_nuc_y - eps_neu_y
burn = np.sign(diff_ary) * np.log10(np.max([np.abs(diff_ary), np.ones_like(diff_ary)], axis=0))

X, Y = np.meshgrid(final_times, y_ary)
Z = burn
if log:
    Z = np.log10(Z)

CS2 = ax.contourf(X, Y, Z, cmap=cmap, levels=np.round(np.linspace(prop_lim[0], prop_lim[1], num_levels), 3),
                  vmin=prop_lim[0], vmax=prop_lim[1])
        
ax.invert_xaxis()    
ax.set_ylabel("$r \,[\\rm{R}_{\\odot}]$")
ax.set_xlabel(r'$\log_{10}$(time until collapse / yr)')
ax.set_title(str(MASSES_ARY[mass_ind]) + "$\,\\rm{M}_{\\odot}$")

# Colorbar
bar = fig.colorbar(CS2, ax=ax, 
                   # orientation="horizontal", location="top", anchor=(0, 0), 
                   pad=0.05)
ax.set_xlim(xlim[0], xlim[1])
ax.set_yscale("log")





script_efficient_mesa_data_storage.py wordt weergegeven.